

if [ $# -lt 2 ]
then
	echo "usage: $0 hostname ipaddress"
	exit 1
fi

echo "
define host{
        use                     linux-server
        host_name               $1
        alias                   $1
        address                 $2
}

"

