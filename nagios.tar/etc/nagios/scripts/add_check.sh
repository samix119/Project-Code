echo "

define service{
        use                             hourly-service
        host_name                       relay$1.email360api.com
        service_description             Mailq Stats
        check_command                   check_nrpe!gen_mail_stat
        }
" >> $2
