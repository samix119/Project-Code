for i in `awk {'print $1'} file | grep ^im`; do cp /etc/nagios/objects/email360.in/parentre1/re1.email360.in.cfg $i.cfg; sed -i s/re1.email360.in/$i/g $i.cfg; done
